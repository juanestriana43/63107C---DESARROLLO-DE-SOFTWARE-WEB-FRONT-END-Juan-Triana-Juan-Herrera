import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorscheModelos718SPYDERRSComponent } from './porsche.modelos.718.spyder.rs.component';

describe('PorscheModelos718SPYDERRSComponent', () => {
  let component: PorscheModelos718SPYDERRSComponent;
  let fixture: ComponentFixture<PorscheModelos718SPYDERRSComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PorscheModelos718SPYDERRSComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PorscheModelos718SPYDERRSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
