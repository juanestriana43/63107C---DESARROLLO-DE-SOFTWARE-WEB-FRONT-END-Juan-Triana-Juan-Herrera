import { Component } from '@angular/core';

@Component({
  selector: 'app-porsche.modelos.718.spyder.rs',
  standalone: true,
  imports: [],
  templateUrl: './porsche.modelos.718.spyder.rs.component.html',
  styleUrl: './porsche.modelos.718.spyder.rs.component.css'
})
export class PorscheModelos718SPYDERRSComponent {

}
