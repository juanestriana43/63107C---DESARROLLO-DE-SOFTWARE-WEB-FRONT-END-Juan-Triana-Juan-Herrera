import { Component } from '@angular/core';

@Component({
  selector: 'app-porsche.modelos.911.gts',
  standalone: true,
  imports: [],
  templateUrl: './porsche.modelos.911.gts.component.html',
  styleUrl: './porsche.modelos.911.gts.component.css'
})
export class PorscheModelos911GtsComponent {

}
