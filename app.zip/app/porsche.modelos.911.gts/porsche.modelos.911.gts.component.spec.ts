import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorscheModelos911GtsComponent } from './porsche.modelos.911.gts.component';

describe('PorscheModelos911GtsComponent', () => {
  let component: PorscheModelos911GtsComponent;
  let fixture: ComponentFixture<PorscheModelos911GtsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PorscheModelos911GtsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PorscheModelos911GtsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
