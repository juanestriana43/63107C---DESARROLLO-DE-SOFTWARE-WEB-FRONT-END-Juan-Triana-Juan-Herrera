import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorscheModelosComponent } from './porsche.modelos.component';

describe('PorscheModelosComponent', () => {
  let component: PorscheModelosComponent;
  let fixture: ComponentFixture<PorscheModelosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PorscheModelosComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PorscheModelosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
