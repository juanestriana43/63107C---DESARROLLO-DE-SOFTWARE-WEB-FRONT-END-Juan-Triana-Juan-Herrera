document.addEventListener('DOMContentLoaded', function() {
    var container = document.querySelector('.Container-Page-Model');

    setTimeout(function() {
        container.classList.add('show');
    }, 500);
});
