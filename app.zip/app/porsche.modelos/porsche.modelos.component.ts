import { Component } from '@angular/core';

@Component({
  selector: 'app-porsche.modelos',
  standalone: true,
  imports: [],
  templateUrl: './porsche.modelos.component.html',
  styleUrl: './porsche.modelos.component.css'
})
export class PorscheModelosComponent {

}
