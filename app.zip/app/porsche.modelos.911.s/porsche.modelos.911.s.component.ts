import { Component } from '@angular/core';

@Component({
  selector: 'app-porsche.modelos.911.s',
  standalone: true,
  imports: [],
  templateUrl: './porsche.modelos.911.s.component.html',
  styleUrl: './porsche.modelos.911.s.component.css'
})
export class PorscheModelos911SComponent {

}
