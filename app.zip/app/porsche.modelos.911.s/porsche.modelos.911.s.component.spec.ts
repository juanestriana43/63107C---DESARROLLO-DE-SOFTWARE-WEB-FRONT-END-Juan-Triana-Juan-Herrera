import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorscheModelos911SComponent } from './porsche.modelos.911.s.component';

describe('PorscheModelos911SComponent', () => {
  let component: PorscheModelos911SComponent;
  let fixture: ComponentFixture<PorscheModelos911SComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PorscheModelos911SComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PorscheModelos911SComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
